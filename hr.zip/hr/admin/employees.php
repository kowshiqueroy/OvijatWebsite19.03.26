<?php
/**
 * Employee List Page
 * Core PHP Employee Management System
 */

define('IS_ADMIN_PAGE', true);
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

requireLogin();

$pageTitle = 'Employees';
$currentPage = 'employees';

$filter = [
    'office' => $_GET['office'] ?? '',
    'department' => $_GET['department'] ?? '',
    'unit' => $_GET['unit'] ?? '',
    'position' => $_GET['position'] ?? '',
    'status' => $_GET['status'] ?? '',
    'bank_name' => $_GET['bank_name'] ?? '',
    'blood_group' => $_GET['blood_group'] ?? '',
    'search' => $_GET['search'] ?? ''
];

$isFiltered = !empty(array_filter($filter));
$filterSubmitted = true; 

$perPage = $isFiltered ? 50 : 5;
$pageNum = max(1, (int)($_GET['page'] ?? 1));
$totalEmployees = 0;
$totalPages = 1;
$employees = [];
$balances = [];
if ($filterSubmitted) {
    $totalEmployees = countAllEmployees($filter);
    $totalPages = $totalEmployees > 0 ? (int)ceil($totalEmployees / $perPage) : 1;
    $employees = getAllEmployees($filter, $perPage, ($pageNum - 1) * $perPage);
    $employeeIds = array_column($employees, 'id');
    $balances = !empty($employeeIds) ? getBatchEmployeeBalances($employeeIds) : [];
}

// CSV export — must run before any HTML output
if ($filterSubmitted && isset($_GET['export']) && $_GET['export'] === 'csv') {
    // For CSV we need all employees (no pagination limit)
    $allEmployees = getAllEmployees($filter);
    $empIds = array_column($allEmployees, 'id');
    $balances = getBatchEmployeeBalances($empIds);

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="employees_' . date('Y-m-d') . '.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Emp ID','Name','Office','Department','Unit','Position','Basic Salary','PF %','Joining Date','Status','Loan Balance','PF Balance']);
    foreach ($allEmployees as $emp) {
        $bal = $balances[$emp['id']] ?? ['loan_balance' => 0, 'pf_balance' => 0];
        fputcsv($out, [
            generateEmployeeID($emp['id'], $emp['office_code'], $emp['dept_code']),
            $emp['emp_name'],
            $emp['office_name'],
            $emp['department'],
            $emp['unit'] ?? '',
            $emp['position'],
            $emp['basic_salary'],
            $emp['pf_percentage'],
            $emp['joining_date'] ?? '',
            $emp['status'],
            number_format($bal['loan_balance'], 2),
            number_format($bal['pf_balance'], 2),
        ]);
    }
    fclose($out);
    exit;
}

$offices = getOfficeList();
$departments = getDepartmentList($filter['office']);
$units = getUnitList($filter['department']);
$positions = getPositionList($filter['department']);
$banks = getBankList();
$bloodGroups = getBloodGroupList();

if (isset($_GET['msg'])) {
    $messages = [
        'updated' => 'Employee updated successfully',
        'rejoined' => 'Employee rejoined successfully'
    ];
    $msg = $messages[$_GET['msg']] ?? '';
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header d-flex justify-content-between align-items-center flex-wrap gap-3">
    <div>
        <h4 class="mb-1">Employees</h4>
        <small class="text-muted">Manage employee records</small>
    </div>
    <div class="d-flex gap-2">
        <?php if (!empty($employees)): ?>
        <a href="employees.php?<?php echo http_build_query(array_filter($filter)); ?>&export=csv" class="btn btn-outline-success">
            <i class="bi bi-download me-1"></i> Download CSV
        </a>
        <?php endif; ?>
        <a href="employee-import.php" class="btn btn-success">
            <i class="bi bi-file-earmark-spreadsheet me-1"></i> Import CSV
        </a>
        <a href="employee-add.php" class="btn btn-primary">
            <i class="bi bi-plus-lg me-1"></i> Add Employee
        </a>
    </div>
</div>

<?php if (!empty($msg)): ?>
    <?php showAlert($msg); ?>
<?php endif; ?>

<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0"><i class="bi bi-funnel me-2"></i>Filter Employees</h5>
    </div>
    <div class="card-body">
        <form method="GET" action="" class="row g-2">
            <div class="col-md-2">
                <label class="form-label small mb-1">Office</label>
                <select name="office" class="form-select form-select-sm filter-select" data-target="department">
                    <option value="">All Offices</option>
                    <?php foreach ($offices as $off): ?>
                        <option value="<?php echo htmlspecialchars($off['office_name']); ?>" 
                            <?php echo $filter['office'] === $off['office_name'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($off['office_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small mb-1">Department</label>
                <select name="department" class="form-select form-select-sm filter-select">
                    <option value="">All Departments</option>
                    <?php foreach ($departments as $dept): ?>
                        <option value="<?php echo htmlspecialchars($dept['department']); ?>"
                            <?php echo $filter['department'] === $dept['department'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($dept['department']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-1">
                <label class="form-label small mb-1">Unit</label>
                <select name="unit" class="form-select form-select-sm filter-select">
                    <option value="">All</option>
                    <?php foreach ($units as $u): ?>
                        <option value="<?php echo htmlspecialchars($u); ?>"
                            <?php echo $filter['unit'] === $u ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($u); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small mb-1">Position</label>
                <select name="position" class="form-select form-select-sm filter-select">
                    <option value="">All Positions</option>
                    <?php foreach ($positions as $pos): ?>
                        <option value="<?php echo htmlspecialchars($pos); ?>"
                            <?php echo $filter['position'] === $pos ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($pos); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-1">
                <label class="form-label small mb-1">Status</label>
                <select name="status" class="form-select form-select-sm">
                    <option value="">All</option>
                    <?php $statuses = ['Active', 'Inactive', 'Resigned', 'Terminated']; ?>
                    <?php foreach ($statuses as $s): ?>
                        <option value="<?php echo $s; ?>" <?php echo $filter['status'] === $s ? 'selected' : ''; ?>>
                            <?php echo $s; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-1">
                <label class="form-label small mb-1">Bank</label>
                <select name="bank_name" class="form-select form-select-sm">
                    <option value="">All</option>
                    <?php foreach ($banks as $b): ?>
                        <option value="<?php echo htmlspecialchars($b); ?>" <?php echo $filter['bank_name'] === $b ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($b); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-1">
                <label class="form-label small mb-1">Blood</label>
                <select name="blood_group" class="form-select form-select-sm">
                    <option value="">All</option>
                    <?php foreach ($bloodGroups as $bg): ?>
                        <option value="<?php echo htmlspecialchars($bg); ?>" <?php echo $filter['blood_group'] === $bg ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($bg); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small mb-1">Search Name/ID</label>
                <div class="input-group input-group-sm">
                    <input type="text" name="search" class="form-control" placeholder="Search..." value="<?php echo htmlspecialchars($filter['search']); ?>">
                    <button type="submit" class="btn btn-primary"><i class="bi bi-search"></i></button>
                    <a href="employees.php" class="btn btn-outline-secondary" title="Clear All"><i class="bi bi-x-circle"></i></a>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">
            <?php echo !$isFiltered ? 'Latest 5 ' : ''; ?>Employee Records (<?php echo $totalEmployees; ?>)
        </h5>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>ID</th>
                        <th>Photo</th>
                        <th>Name</th>
                        <th>Office</th>
                        <th>Department</th>
                        <th>Position</th>
                        <th>Official Phone</th>
                        <th>Personal Phone</th>
                        <th>Basic Salary</th>
                        <th>PF Balance</th>
                        <th>Loan Balance</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($employees)): ?>
                        <tr>
                            <td colspan="12" class="text-center text-muted py-4">No employees found</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($employees as $emp): ?>
                            <tr>
                                <td>
                                    <span class="badge bg-dark">
                                        <?php echo generateEmployeeID($emp['id'], $emp['office_code'], $emp['dept_code']); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($emp['photo']): ?>
                                        <img src="../uploads/photos/<?php echo htmlspecialchars($emp['photo']); ?>"
                                             alt="" class="rounded-circle" width="40" height="40" style="object-fit: cover;">
                                    <?php else: ?>
                                        <div class="bg-secondary rounded-circle d-flex align-items-center justify-content-center"
                                             style="width: 40px; height: 40px;">
                                            <i class="bi bi-person text-white"></i>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <strong><?php echo htmlspecialchars($emp['emp_name']); ?></strong>
                                    <br><small class="text-muted"><?php echo htmlspecialchars($emp['unit'] ?? 'N/A'); ?></small>
                                </td>
                                <td><?php echo htmlspecialchars($emp['office_name']); ?></td>
                                <td><?php echo htmlspecialchars($emp['department']); ?></td>
                                <td><?php echo htmlspecialchars($emp['position']); ?></td>
                                <td><?php echo htmlspecialchars($emp['official_phone'] ?? '-'); ?></td>
                                <td><?php echo htmlspecialchars($emp['personal_phone'] ?? '-'); ?></td>
                                <td><?php echo formatCurrency($emp['basic_salary']); ?></td>
                                <?php $bal = $balances[$emp['id']] ?? ['pf_balance' => 0, 'loan_balance' => 0]; ?>
                                <td class="text-success"><?php echo number_format($bal['pf_balance'], 2); ?></td>
                                <td class="<?php echo $bal['loan_balance'] > 0 ? 'text-danger' : 'text-muted'; ?>">
                                    <?php echo number_format($bal['loan_balance'], 2); ?>
                                </td>
                                <td>
                                    <span class="badge badge-<?php echo strtolower($emp['status']); ?>">
                                        <?php echo $emp['status']; ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="employee-add.php?edit=<?php echo $emp['id']; ?>"
                                           class="btn btn-outline-primary" title="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <?php if ($emp['status'] === 'Resigned' || $emp['status'] === 'Terminated'): ?>
                                        <a href="employee-rejoin.php?id=<?php echo $emp['id']; ?>"
                                           class="btn btn-outline-success" title="Rejoin">
                                            <i class="bi bi-person-plus"></i>
                                        </a>
                                        <?php endif; ?>
                                        <a href="../public/profile.php?id=<?php echo $emp['id']; ?>"
                                           class="btn btn-outline-info" title="View Profile" target="_blank">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if ($totalPages > 1): ?>
    <div class="card-footer">
        <?php
        $baseUrl = 'employees.php?' . http_build_query(array_filter($filter));
        renderPagination($pageNum, $totalPages, $baseUrl);
        ?>
    </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
